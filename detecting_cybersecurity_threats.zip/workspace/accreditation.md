Dataset obtained from [Kaggle: BETH Dataset](https://www.kaggle.com/datasets/katehighnam/beth-dataset)

Paper explaining the dataset in detail:
[BETH Dataset: Real Cybersecurity Data for Anomaly Detection Research](https://www.gatsby.ucl.ac.uk/~balaji/udl2021/accepted-papers/UDL2021-paper-033.pdf)